﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace CodeHelperClone.Models
{
    public class ExposrtCSVFile
    {
        public int coursePrice { get; set; }
        public string name { get; set; }
        public string courseName { get; set; }
        public string email { get; set; }
        public string enrollDate { get; set; }
    }
}